import client from '../db.js'

class Category {
	async getCategory() {
		const response = await client.query(
			`
        select * from category
		order by id
        `
		)
		return response
	}
	async getCategoryById(id) {
		const response = await client.query(
			`
        select * from category
        WHERE categorys.id = $1
        `,
			[id]
		)
		if (response.rows[0]) {
			return response.rows[0]
		} else {
			return 'Не найдено'
		}
	}
	async addCategory(data) {
		const response = await client.query(
			`INSERT INTO category (name)
        VALUES ($1)
        RETURNING *`,
			[data.name]
		)
		return response.rows[0]
	}

	async updateCategory(id, data) {
		const response = await client.query(
			`UPDATE category
        SET name = $1
        WHERE id = $2
        RETURNING *`,
			[data.name, id]
		)
		return response.rows[0]
	}

	async deleteCategory(id) {
		const response = await client.query(
			'DELETE FROM category WHERE id = $1',
			[id]
		)
		return response.rows[0]
	}
}

export default Category