import client from "../db.js";
import ApiError from "../exceptions/api-error.js";

class UserService {
  async loginuser(email, password) {
    const response = await client.query(
      `
        select id, email, password from users where email = $1 and password = $2
        `,
      [email, password]
    );
    //Опцианально (необязательно)
    //Проверяет есть ли такой пользователь в бд, если нет ничего не отправляет на клиент
    if (response.rows[0] === null || response.rows[0] === undefined) {
      throw ApiError.BadRequest("Неправильный логин или пароль");
    }
    return response;
  }

  async getUsers() {
    const response = await client.query(
      `
        select * from users
        order by id
        `
    );
    return response;
  }
  async emailUsers(email) {
    const response = await client.query(
      `
      SELECT * FROM users
      WHERE email = $1
        `,
        [email]
    );
    if (response.rows.length === 0) {
      const error = new Error('Пользователя с такой почтой не существует');
      error.status = 500;
      throw error;
  }
    return response.rows[0];
  }


 

  }

export default UserService;