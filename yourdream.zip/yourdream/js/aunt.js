window.onload = function () {
	const checkbox = document.querySelector('.nav-container1 .checkbox');
		const hamburgerLines = document.querySelector('.nav-container1 .hamburger-lines');
		const menuItems = document.querySelector('.nav-container1 .menu-items');
		console.log("DOM загружен");
	

		document.querySelector('.nav-container1 .menu-items li:nth-child(2) a').addEventListener('click', function (event) {
			event.preventDefault();
			handleMenuItemClick();
			window.scrollTo(0, 550);
		});
	

	
		function handleMenuItemClick() {
			checkbox.checked = false;
			hamburgerLines.querySelector('.line1').style.transform = '';
			hamburgerLines.querySelector('.line2').style.transform = '';
			hamburgerLines.querySelector('.line3').style.transform = '';
		}
	let id
	const authForm = document.querySelector('#FormAvtoriz')
	authForm.addEventListener('submit', async function (event) {
		event.preventDefault()
		const myHeaders = new Headers()
		myHeaders.append('Content-Type', 'application/json')
		const email = document.querySelector('#email')
		const password = document.querySelector('#password')
		const data = JSON.stringify({
			login: login.value,
			password: password.value,
		})
		const requestOptions = {
			method: 'POST',
			headers: myHeaders,
			body: data,
			redirect: 'follow',
		}

		fetch(`${window.API_URL}/users/email`, requestOptions)
			.then(response => {
				if (response.ok) {
					return response.json()
				} else {
					throw new Error('Неправильный логин или пароль')
				}
			})
			.then(data => {
				if (login.value === 'admin' && password.value === 'adminuser') {
					localStorage.setItem('userId', data[0].id)
					window.location.href = '/Admin_categoryservice.html'
				} else {
					localStorage.setItem('userId', data[0].id)
					window.location.href = '/Record.html'
				}
			})
			.catch(error => alert(error.message))
	})
	document.getElementById('FormRecovery').addEventListener('submit', function (e) {
		e.preventDefault()
		let email = document.getElementById('email').value

		fetch(`${window.API_URL}/users/emailUsers/${email}`, requestOptions)
			.then(response => {
				if (!response.ok) {
					if (response.status === 500) {
						throw new Error('Пользователь с такой почтой не зарегистрирован')
					} else {
						throw new Error('Произошла ошибка при запросе к серверу')
					}
				}
				return response.json()
			})
        
