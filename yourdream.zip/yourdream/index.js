import * as dotenv from "dotenv";
import express from "express";



dotenv.config();

const PORT = process.env.PORT || 8080;

const app = express();



app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", process.env.CLIENT_URL);
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  );
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
  } else {
    next();
  }
});

// app.use("/user", userRouter);
// app.use("/services", servicesRouter);
// app.use("/reviews", reviewsRouter);
// app.use("/master", masterRouter);
// app.use("/appointments", appointmentsRouter);
// app.use("/news", newsRouter);


const start = () => {
  try {
    app.listen(PORT, () => console.log(`server started on port ${PORT}`));
  } catch (e) {
    console.log(e);
  }
};

start();